Welcome to the GRSB help/read me file:
	Controls:
		Gui:
			Right Arrow: Select
			Down Arrow: Scroll Up
			Up Arrow: Scroll Down
		Game:
			Player1:
				W: Jump
				A: Go Left
				D: Go Right
				Z: Punch
			Player2:
				Up Arrow: Jump
				Left Arrow: Go Left
				Right Arrow: Go Right
				(Right) Shift: Punch

History of the game:
		In a class at school we were learning Python 3 computer
	language. I decided to go a little a-head and learn Python 3 and 
	Pygame (graphics and stuff) to make a little extra credit assignment.

Rights:
		Giant Robot Super Battles, its code and art assets (images) 
	are the property and intellectual property of Christopher Greeley. 
	However you may re-distribute Giant Robot Super Battes, under the 
	condition that you provide a link to www.gcggames.webs.com
	and cite Christopher Greeley as Giant Robot Super Battles creator 
	and owner.
